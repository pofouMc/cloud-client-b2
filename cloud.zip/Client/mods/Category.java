package Client.mods;

public enum Category {

	RENDER,
	CATEGORY;
	
}
