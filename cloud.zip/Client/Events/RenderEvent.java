package Client.Events;



public class RenderEvent extends Event {}
